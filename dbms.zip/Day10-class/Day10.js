
//----------------------------------------------------
//DEMO -- Update the inserted documents 
//----------------------------------------------------

// update my_first_collectIon  set my_third_field = 'Updated' // Update Many
my_first_collectIon.updateOne({},{$set : {my_third_field : "Updated" } })
db.my_first_collectIon.updateMany({},{$set : {my_fourth_field : "Updated_again" } })
db.my_first_collectIon.updateMany({},{$set : {my_fifth_field : "Updated_here_again" } }) 

// update members collection set status = 'Temporary ' for all members who belong to Pune (CI)
// /pune/ lower(city) like '%pune%'

db.LMS_MEMBERS.updateMany({CITY:/pune/i},{$set:{MEMBERSHIP_STATUS:"Temporary"} });
db.LMS_MEMBERS.find({CITY:/Pune/i},{});
db.LMS_MEMBERS.find({},{});

// Upsert to true 
db.LMS_MEMBERS.updateMany({CITY:"BOGUS_CITY"},{$set:{MEMBERSHIP_STATUS:"Permanent" , MEMBER_NAME : 'Bogus_member'} });
db.LMS_MEMBERS.updateMany({CITY:"BOGUS_CITY"},{$set:{MEMBERSHIP_STATUS:"permanent" , MEMBER_NAME : 'Bogus_member'} },{upsert : true});

db.LMS_MEMBERS.find({CITY:"BOGUS_CITY"},{});

// update book details and set edition number = 10 for all books with python category
/*
update  LMS_BOOK_DETAILS
set  BOOK_EDITION = 10
where category = 'python'
*/

db.LMS_BOOK_DETAILS.updateMany({CATEGORY : /python/i},{$set : {BOOK_EDITION : NumberInt(10)}})
db.LMS_BOOK_DETAILS.find({CATEGORY : /python/i},{});

// update book details and set edition number = 15 and price 10,000 for all books with python category
// update lms_book_details set edition = 15 , price = 10000 where category   = 'python';

db.LMS_BOOK_DETAILS.updateMany({CATEGORY : /python/i},{$set : {BOOK_EDITION : NumberInt(15) , PRICE : NumberInt(10000)}})


//----------------------------------
//DEMO -- Simple selects using find()
//----------------------------------
// select *  from customer 
db.customer.find({},{});

// select *  from customer where address = 'Pune'
db.customer.find({address: "Pune"},{});
db.customer.find({address: { $eq: "Pune" }},{}); // $eq is implicit in above statement

// select * from customer where address like '%pune%'
db.getCollection("customer").find({ "address" : /pune/});
db.getCollection("customer").find({ "address" : { $regex: /pune/ } });

// select * from customer where lower(address) like '%pune%'
db.getCollection("customer").find({ "address" : /pune/i}); 
db.getCollection("customer").find({  "address" : { $regex: /pune/i } });

// select * from customer where street_no = 123
db.customer.find({"billing_address.street_no": 123},{});
db.customer.find({"billing_address.street_no": {$eq: 123}},{});

// select * from  customer.Cart.added_products[] where [].product_id = 'X001' // invalid syntax just for reference
db.customer.find({ "Cart.added_products": {$elemMatch: { "product_id" : "X001"} }  },{});

// select * from  customer.Cart.added_products[] where [].product_id = 'X003' // invalid syntax just for reference
db.customer.find({ "Cart.added_products": {$elemMatch: { "product_id" : "X003"} }  },{});

// select * from customer where total_cost > 350
db.customer.find({"Cart.total_cost": {$gt: 350}},{});

// select * from customer where total_cost > 350 and address = 'Pune'
db.customer.find({"Cart.total_cost": {$gt: 350} , address : "Pune"},{});
db.customer.find({  $and: [{"Cart.total_cost": {$gt: 350} }, {address : "Pune"}]  }   ,{});

// db.customer.find({  $or: [{"Cart.total_cost": {$gt: 350} }, {address : "Pune"}]  }   ,{});

// select * from customer where address in ('Pune','Chennai')
db.customer.find({address: { $in : ["Pune","Chennai"]}},{});

// select * from customer where lower(address) in ('pune','chennai')
db.customer.find({address: { $in : [/pune/i,/chennai/i]}},{});

// select * from customer where address != 'Chennai'
db.customer.find({address: { $ne : "Chennai"}},{});

// select * from customer where address != 'chennai' // not so useful use case of toLowerCase()
db.customer.find({address: { $ne : "Chennai".toLowerCase() }},{});
db.customer.find({address: { $ne : "Chennai".toUpperCase() }},{}); 

// db.customer.find({},{"name_lower": $_id.name.toLowerCase()}); // good use case of toLowerCase() 


/*--------------------------------------------
  Exercises on simple selects 
-------------------------------------------- */

// Name of the supplier that reside in chennai  [Case insensitive ]

db.LMS_SUPPLIERS_DETAILS.find({ADDRESS:/Chennai/i},{"SUPPLIER_NAME":1,"_id":0})
db.LMS_SUPPLIERS_DETAILS.find({ADDRESS:"Chennai"},{"SUPPLIER_NAME":1,"_id":0})

// Name of the supplier that reside in chennai/delhi/ahmedabad  [Case insensitive ]
db.LMS_SUPPLIERS_DETAILS.find({ADDRESS:{$in:[/Chennai/i,/delhi/i,/ahmedabad/i]}},{"SUPPLIER_NAME":1,"_id":0})

// Name of the supplier , contact , email , Address 
// who resides in either Mumbai Or Delhi [CI] and email does not belong to gmail account


db.LMS_SUPPLIERS_DETAILS.find({ $and: [{"ADDRESS": {$in: [/Mumbai/i, /Delhi/i]}},{"EMAIL":{$nin: [/gmail/i]}}]}, {"SUPPLIER_NAME":1,"_id":0})

// book_name,book_publication
// of all books placed on rack_num = a1 and publication is not equal to tata mcgraw hill

db.LMS_BOOK_DETAILS.find({ $and: [{"RACK_NUM": /A1/i},{"PUBLICATION" : {$nin: [/tata mcgraw hill/i]}}]},{"BOOK_TITLE":1,"PUBLICATION":1,"_id":0})


db.LMS_BOOK_DETAILS.find({ $and: [{"RACK_NUM": /a1/i},{"PUBLICATION" : {$ne: "Tata Mcgraw Hill" }}]},{"BOOK_TITLE":1,"PUBLICATION":1,"_id":0})


// book_code , member_id of all book issuances which have been fined 


db.LMS_BOOK_ISSUE.find({"FINE_RANGE": {$ne: null}},{"BOOK_CODE":1, "MEMBER_ID":1, "_id":0})
// Query for embedded json
// book_name and publication whose has atleast one supplier from chennai (CI)

db.EMBEDDED_JSON.find({"BOOKS_SUPPLIED.ADDRESS":{$eq: "CHENNAI"}},{"BOOK_TITLE":1,"PUBLICATION":1,"_id":0});

// Query for embedded json
// book_name and publication whose has atleast one supplier from chennai (CI)



db.EMBEDDED_JSON.find({},{})

db.EMBEDDED_JSON.find({BOOKS_SUPPLIED : { $elemMatch: {ADDRESS : /CHENNAI/i}} },{BOOK_TITLE:1,PUBLICATION:1,BOOKS_SUPPLIED:1});
// BOOKS_SUPPLIED : { $elemMatch: {ADDRESS : /CHENNAI/I}} 

// this query gives similar output since we are using = to chennai , if we have != then we would have different results 
// for more info visit https://www.mongodb.com/docs/manual/reference/operator/query/elemMatch/
db.EMBEDDED_JSON.find({ "BOOKS_SUPPLIED.ADDRESS" : "CHENNAI" },{BOOK_TITLE:1,PUBLICATION:1,BOOKS_SUPPLIED:1});

// DEMO TO DEMONSTRATE USE OF EXISTS IS DIFFERENT FROM not NULLS 
// the query { field : {$ne : null} } check for not-null []

db.test_nulls.insert({"num":1, "contact":"89898989898"});
db.test_nulls.insert({"num":2, "contact":""});
db.test_nulls.insert({"num":3, "contact":null});
db.test_nulls.insert({"num":4});

// This will return all  documents:
db.test_nulls.find();

// This will return the first,second,third documents only: 
//return all documents with a key called "contact" was received during insertion
db.test_nulls.find({"contact":{$exists:false}});

// This will return the first,second document only:
// return all documents with a key called "contact" was received during insertion and also has a not null value 
db.test_nulls.find({"contact":{$ne:null}});

//---------------------------------------------
//EXERCISES on Crud
//------------------------------------------
//IPL 
//------

//Players --> p_name,dob, skill,is_oversea_player  medical_details(last_yoyo_date,is_passed), team_name


db.players.insert({"p_name":"Deoyani", "dob":ISODate("2022-10-18T14:10:30Z"), "skill":"Batsman", "is_oversea_player":"N", "medical_details": {"last_yoyo_date":ISODate("2021-10-28T14:10:30Z"), "is_passed":"Y"}, "team_name":"CSK"});
db.players.insert({"p_name":"Gaby", "dob":ISODate("2022-10-18T14:10:30Z"), "skill":"Bowler", "is_oversea_player":"N", "medical_details": {"last_yoyo_date":ISODate("2022-10-28T14:10:30Z"), "is_passed":"Y"}, "team_name":"Rajasthan Royals"});
db.players.insert({"p_name":"Deepak", "dob":ISODate("2022-05-18T14:10:30Z"), "skill":"All rounder", "is_oversea_player":"N", "medical_details": {"last_yoyo_date":ISODate("2020-10-28T14:10:30Z"), "is_passed":"Y"}, "team_name":"Delhi Capitals"});
db.players.insert({"p_name":"Kirti", "dob":ISODate("2022-01-18T14:10:30Z"), "skill":"Bowler", "is_oversea_player":"N", "medical_details": {"last_yoyo_date":ISODate("2022-10-21T14:10:30Z"), "is_passed":"Y"}, "team_name":"CSK"});
db.players.insert({"p_name":"Shoaib", "dob":ISODate("2020-10-18T14:10:30Z"), "skill":"All rounder", "is_oversea_player":"N", "medical_details": {"last_yoyo_date":ISODate("2022-10-28T14:10:30Z"), "is_passed":"N"}, "team_name":"Rajasthan Royals"});
db.players.insert({"p_name":"Gaurav", "dob":ISODate("2022-08-18T14:10:30Z"), "skill":"Batsman", "is_oversea_player":"N", "medical_details": {"last_yoyo_date":ISODate("2022-08-28T14:10:30Z"), "is_passed":"Y"}, "team_name":"CSK"});
db.players.insert({"p_name":"Hardik", "dob":ISODate("2022-02-18T14:10:30Z"), "skill":"Bowler", "is_oversea_player":"Y", "medical_details": {"last_yoyo_date":ISODate("2022-11-08T14:10:30Z"), "is_passed":"Y"}, "team_name":"CSK"});
db.players.insert({"p_name":"Chahal", "dob":ISODate("2022-03-18T14:10:30Z"), "skill":"Keeper", "is_oversea_player":"Y", "medical_details": {"last_yoyo_date":ISODate("2022-10-28T14:10:30Z"), "is_passed":"Y"}, "team_name":"Delhi Capitals"});
db.players.insert({"p_name":"Sachin", "dob":ISODate("2022-10-18T14:10:30Z"), "skill":"Fielder", "is_oversea_player":"Y", "medical_details": {"last_yoyo_date":ISODate("2022-10-28T14:10:30Z"), "is_passed":"N"}, "team_name":"Rajasthan Royals"});
db.players.insert({"p_name":"Jadeja", "dob":ISODate("2022-08-18T14:10:30Z"), "skill":"Batsman", "is_oversea_player":"Y", "medical_details": {"last_yoyo_date":ISODate("2022-05-28T14:10:30Z"), "is_passed":"Y"}, "team_name":"CSK"});
db.players.insert({"p_name":"Smith", "dob":ISODate("2022-10-18T14:10:30Z"), "skill":"Bowler", "is_oversea_player":"Y", "medical_details": {"last_yoyo_date":ISODate("2022-04-28T14:10:30Z"), "is_passed":"Y"}, "team_name":"Delhi Capitals"});
db.players.insert({"p_name":"Gayle", "dob":ISODate("2022-11-18T14:10:30Z"), "skill":"Batsman", "is_oversea_player":"Y", "medical_details": {"last_yoyo_date":ISODate("2022-10-18T14:10:30Z"), "is_passed":"N"}, "team_name":"Rajasthan Royals"});

//Teams--> t_name,owner,budget, overseas_players(array which will contain overseas player)

db.Teams.insert({"t_name":"CSK", "owner":"Dhoni","budget":"500 cr", "overseas_players":[{"p_name":"Hardik"},{"p_name":"Jadeja"}] })
db.Teams.insert({"t_name":"Rajasthan Royals", "owner":"Ambani","budget":"1000 cr", "overseas_players":[{"p_name":"Gayle"},{"p_name":"Sachin"}] })
db.Teams.insert({"t_name":"Delhi Capitals", "owner":"Shahrukh","budget":"800 cr", "overseas_players":[{"p_name":"Smith"},{"p_name":"Chahal"}] })

//Scores --> p_name, skill, total_runs(if batting), total_wickets(if bowlers)

db.Scores.insert({"p_name":"Deoyani","skill":"Batsman","total_runs":10000,"total_wickets":0})
db.Scores.insert({"p_name":"Gaby","skill":"Bowler","total_runs":0,"total_wickets":6000})
db.Scores.insert({"p_name":"Deepak","skill":"All rounder","total_runs":6000,"total_wickets":5000})
db.Scores.insert({"p_name":"Kirti","skill":"Bowler","total_runs":0,"total_wickets":5900})
db.Scores.insert({"p_name":"Gaurav","skill":"Batsman","total_runs":9600,"total_wickets":0})
//-- Create the collections
//12 Players (6 Overseas, 6 Indian)
//3 teams 
//5 Scores
//
//"medical_details" : {"last_yoyo_date" : ISO() , is_passed : "Y"}
//"overseas_players" : [{"p_name" : "Gayle" },{"p_name" : "Smith" }]
//---------------------------------------------------------------------------------------
//------------------------------------------------------------------------------
//Update and Delete Exercise on our Cricket Data that we created in last step 
//------------------------------------------------------------------------------

//  Update all players total_runs who are batsman to 1000 runs

db.Scores.updateMany({"skill":"Batsman"},{$set:{"total_runs":1000}})
db.Scores.find()
// Update all players total_wickets who are bowlers to 1000 wickets
db.Scores.updateMany({"skill":"Bowler"},{$set:{"total_wickets":1000}})

// update all players yoyo test passed status to failed 

db.players.updateMany({"medical_details.is_passed":"Y"}, {$set:{"medical_details.is_passed": "N"}})

db.players.find()
// add a new field named "category" to the Players collection with a default value of Outstanding
db.players.updateMany({}, {$set:{"category":"outstanding"}})


// add a new field named "homeGround" to the Teams collection with the default value null
db.Teams.find()
db.Teams.updateMany({},{$set:{"homeground":null}})
// Update HomeGround field of Teams collection

db.Teams.updateMany({"t_name":"Delhi Capitals"},{$set:{"homeground":"Delhi"}})
db.Teams.updateMany({"t_name":"CSK"},{$set:{"homeground":"Chennai"}})
db.Teams.updateMany({"t_name":"Rajasthan Royals"},{$set:{"homeground":"Rajasthan"}})

// for Delhi Capitals --> Delhi
// for (CSK) Mumbai Indians --> Chennai/Mumbai
// for Rajasthan Royals --> Rajasthan

// Add a new field "no_of_centuries"  with a default value of 5 to all batsman
db.Scores.find()
db.Scores.updateMany({"skill":"Batsman"},{$set:{"no_of_centuries":5}})
// Add a new field "no_of_hatricks"  with a default value of 2 to all bowler
db.Scores.updateMany({"skill":"Bowler"},{$set:{ "no_of_hatricks":2}})
// delete all players that belong to 'Delhi capitals'
db.players.deleteMany({"team_name":"Delhi Capitals"})

db.players.find()
// delete players that were born before '01-12-1980'

db.players.deleteMany({"dob": {$lt:ISODate("1980-12-01T00:00:00Z")}})

//db.players.updateMany({"dob":ISODate("2022-10-18T14:10:30Z")}, {$set:{"dob":ISODate("1980-10-18T00:00:00Z")}})


// delete any one player that belong to 'Mumbai Indians'/CSK

db.players.deleteOne({"team_name": "CSK"})

// just adds value 1 to the budget
db.Teams.find()
db.Teams.updateMany({},{$set:{"budget":1}})

db.Teams.updateMany({},{$inc:{"budget":1}})
// increase all the teams budget by 60
db.Teams.updateMany({},{$inc:{"budget":60}})



