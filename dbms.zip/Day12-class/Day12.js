// -----------------------------
// join tryout 
// -----------------------------

// general syntax [MongoDB does a left join by default ]
/*
{
    from: "<collection to join>",
    localField: "<field from the input documents>",
    foreignField: "<field from the documents of the 'from' collection>",
    as: "<output array field>"
}
*/

// example translation of oracle left join in mongodb using $lookup operator

//select lms_members.* 
// from lms_members left join lms_book_issue 
// on (lms_members.member_id = lms_book_issue.member_id ) ;

db.LMS_MEMBERS.aggregate([
{$lookup : 
    {
        from: "LMS_BOOK_ISSUE",
        localField: "MEMBER_ID",
        foreignField: "MEMBER_ID",
        as: "output array of_issuances"
    }
}    
]
)

// Demo Example but for inner join and not left join 
// all members who have issued a book
// using joins 

//select lms_members.* 
//from lms_members inner JOIN lms_book_issue 
// on (lms_members.member_id = lms_book_issue.member_id ) ;
/*

// Equality Match [Left JOIN]
{
    from: "<collection to join>",
    localField: "<field from the input documents>",
    foreignField: "<field from the documents of the 'from' collection>",
    as: "<output array field>"
}
+ $match
*/
// solution 1 members left join issuances followed by discarding empty issuances 
db.getCollection("LMS_MEMBERS").aggregate(
    [
        { 
            "$lookup" : { 
                "from" : "LMS_BOOK_ISSUE", 
                "localField" : "MEMBER_ID", 
                "foreignField" : "MEMBER_ID", 
                "as" : "issued_members"
            }
        }, 
        { 
            "$match" : { 
                "issued_members"  : { 
                    "$ne" : []
                }
            }
        }
    ]
);

//  name of the suppliers who reside in 'pune/mumbai/chennai'[CI]
// who have supplied a book placed on rack_numbers A1/A2/A3
// and their category is not JAVA 


/*
select lms_book_details.book_title
from lms_suppliers_details inner join lms_book_details on (lms_suppliers_details.supplier_id = lms_book_details.supplier_id )
where lower(lms_suppliers_details.address) in ('pune','mumbai','chennai')
and rack_num in ('A1','A2','A3')
and category != 'JAVA';
*/


// solution 1 with 3 match clauses 
db.getCollection("LMS_BOOK_DETAILS").aggregate(
    [
        {
            "$lookup" : {
                "from" : "LMS_SUPPLIERS_DETAILS",
                "localField" : "SUPPLIER_ID",
                "foreignField" : "SUPPLIER_ID",
                "as" : "supplier_details_array"
            }
        }, 
        {
            "$unwind" : {
                "path" : "$supplier_details_array"
            }
        }, 
        {
            "$match" : {
                "supplier_details_array.ADDRESS" : {
                    "$in" : [
                        /pune/i,
                        /mumbai/i,
                        /chennai/i
                    ]
                }
            }
        }, 
        {
            "$match" : {
                "RACK_NUM" : {
                    "$in" : [
                        "A1",
                        "A2",
                        "A3"
                    ]
                }
            }
        }, 
        {
            "$match" : {
                "CATEGORY" : {
                    "$ne" : "JAVA"
                }
            }
        }
    ]
);

// solution 2 with one match and using and clause
db.getCollection("LMS_BOOK_DETAILS").aggregate(
    [
        {
            "$lookup" : {
                "from" : "LMS_SUPPLIERS_DETAILS",
                "localField" : "SUPPLIER_ID",
                "foreignField" : "SUPPLIER_ID",
                "as" : "supplier_details_array"
            }
        }, 
        {
            "$unwind" : {
                "path" : "$supplier_details_array"
            }
        }, 
        {
            "$match" : {
                "$and" : [
                    {
                        "supplier_details_array.ADDRESS" : {
                            "$in" : [
                                /pune/i,
                                /mumbai/i,
                                /chennai/i
                            ]
                        }
                    },
                    {
                        "RACK_NUM" : {
                            "$in" : [
                                "A1",
                                "A2",
                                "A3"
                            ]
                        }
                    },
                    {
                        "CATEGORY" : {
                            "$ne" : "JAVA"
                        }
                    }
                ]
            }
        }, 
        {
            "$project" : {
                "_id" : 0.0,
                "Book_Name" : "$BOOK_TITLE"
            }
        }
    ]
);


db.getCollection("LMS_BOOK_DETAILS").aggregate(
    [
        {
            "$lookup" : {
                "from" : "LMS_SUPPLIERS_DETAILS",
                "localField" : "SUPPLIER_ID",
                "foreignField" : "SUPPLIER_ID",
                "as" : "supplier_details_array"
            }
        }, 
        {
            "$unwind" : {
                "path" : "$supplier_details_array"
            }
        }
]
);

db.getCollection("LMS_BOOK_DETAILS").aggregate(
    [
        {
            "$lookup" : {
                "from" : "LMS_SUPPLIERS_DETAILS",
                "localField" : "SUPPLIER_ID",
                "foreignField" : "SUPPLIER_ID",
                "as" : "supplier_details_array"
            }
        }
 ]
);
//--------------------
// JOINS continued
//--------------------

/*
LMS_SUPPLIER_DETAILS LEFT JOIN LMS_BOOK_DETAILS
ON(LMS_SUPPLIER_DETAILS.SUPPLIER_ID = LMS_BOOK_DETAILS.SUPPLIER_ID)
LEFT JOIN LMS_BOOK_ISSUE ON (LMS_BOOK_DETAILS.BOOK_CODE = LMS_BOOK_ISSUE.BOOK_CODE ) */


db.LMS_SUPPLIERS_DETAILS.aggregate(
[
{
   "$lookup":{
   "from": "LMS_BOOK_DETAILS",
   "localField":"SUPPLIER_ID",
   "foreignField":"SUPPLIER_ID",
   "as":"Book_Details"
   }},
   {"$lookup":{
   "from": "LMS_BOOK_ISSUE",
   "localField":"Book_Details.BOOK_CODE",
   "foreignField":"BOOK_CODE",
   "as":"Book_Issue"
   }
   } 
   ])
   
   
   db.getCollection("LMS_SUPPLIERS_DETAILS").aggregate(
    [
        {
            "$lookup" : {
                "from" : "LMS_BOOK_DETAILS",
                "localField" : "SUPPLIER_ID",
                "foreignField" : "SUPPLIER_ID",
                "as" : "supplied_books"
            }
        }, 
        {
            "$unwind" : {
                "path" : "$supplied_books",
                "preserveNullAndEmptyArrays" : true
            }
        }, 
        {
            "$lookup" : {
                "from" : "LMS_BOOK_ISSUE",
                "localField" : "supplied_books.BOOK_CODE",
                "foreignField" : "BOOK_CODE",
                "as" : "issuance_details"
            }
        }, 
        {
            "$unwind" : {
                "path" : "$issuance_details",
                "preserveNullAndEmptyArrays" : true
            }
        }, 
        {
            "$project" : {
                "SUPPLIER_NAME" : 1.0,
                "title_of_book" : "$supplied_books.BOOK_TITLE",
                "member_id" : "$issuance_details.MEMBER_ID"
            }
        }
    ]
);


// book_code and name of the book which has been issued more than 4 times and has more than 0 suppliers
// (Note: Java how to program has 2 book codes because of different published date)
/*
select lms_book_issue.BOOK_CODE,lms_book_details.BOOK_TITLE, count(*) from
lms_book_details INNER JOIN  lms_book_issue on (lms_book_issue.BOOK_CODE = lms_book_details.BOOK_CODE)
where lms_book_details.supplier_id is not null 
group by lms_book_issue.BOOK_CODE,lms_book_details.BOOK_TITLE
having count(book_issue_no) > 4 
*/

// possible solution 1 
db.getCollection("LMS_BOOK_DETAILS").aggregate(
    [
        { 
            "$lookup" : { 
                "from" : "LMS_BOOK_ISSUE", 
                "localField" : "BOOK_CODE", 
                "foreignField" : "BOOK_CODE", 
                "as" : "Books_issued"
            }
        }, 
        { 
            "$match" : { 
                "Books_issued" : { 
                    "$ne" : [

                    ]
                }, 
                "SUPPLIER_ID" : { 
                    "$ne" : null
                }
            }
        }, 
        { 
            "$unwind" : { 
                "path" : "$Books_issued"
            }
        }, 
        { 
            "$group" : { 
                "_id" : { 
                    "book_code" : "$Books_issued.BOOK_CODE"
                }, 
                "cnt" : { 
                    "$sum" : 1.0
                }
            }
        }, 
        { 
            "$match" : { 
                "cnt" : { 
                    "$gt" : 4.0
                }
            }
        }, 
        { 
            "$project" : { 
                "_id" : 0.0, 
                "cnt" : 1.0, 
                "book_code" : "$_id.book_code"
            }
        }
    ]
);
// possible solution 2
db.getCollection("LMS_BOOK_DETAILS").aggregate(
    [
        { 
            "$lookup" : { 
                "from" : "LMS_BOOK_ISSUE", 
                "localField" : "BOOK_CODE", 
                "foreignField" : "BOOK_CODE", 
                "as" : "Books_issued"
            }
        }, 
        { 
            "$unwind" : { 
                "path" : "$Books_issued"
            }
        }, 
        { 
            "$group" : { 
                "_id" : { 
                    "book_code" : "$Books_issued.BOOK_CODE", 
                    "SUPPLIER_ID" : "$SUPPLIER_ID"
                }, 
                "cnt" : { 
                    "$sum" : 1.0
                }
            }
        }, 
        { 
            "$match" : { 
                "_id.SUPPLIER_ID" : { 
                    "$ne" : null
                }, 
                "cnt" : { 
                    "$gt" : 4.0
                }
            }
        }, 
        { 
            "$project" : { 
                "_id" : 0.0, 
                "cnt" : 1.0, 
                "book_code" : "$_id.book_code"
            }
        }
    ]
);
// possible solution 3 
db.getCollection("LMS_BOOK_DETAILS").aggregate(
    [
        {
            "$lookup" : {
                "from" : "LMS_BOOK_ISSUE",
                "localField" : "BOOK_CODE",
                "foreignField" : "BOOK_CODE",
                "as" : "BOOK_ISSUED"
            }
        }, 
        {
            "$project" : {
                "BOOK_CODE" : 1.0,
                "BOOK_TITLE" : 1.0,
                "SUPPLIER_ID" : 1.0,
                "my_cnt" : {
                    "$size" : "$BOOK_ISSUED"
                }
            }
        }, 
        {
            "$match" : {
                "my_cnt" : {
                    "$gt" : 4.0
                },
                "SUPPLIER_ID" : {
                    "$ne" : null
                }
            }
        }
    ]
);

// apt solution
db.getCollection("LMS_BOOK_DETAILS").aggregate(
    [
        { 
            "$lookup" : { 
                "from" : "LMS_BOOK_ISSUE", 
                "localField" : "BOOK_CODE", 
                "foreignField" : "BOOK_CODE", 
                "as" : "Books_issued"
            }
        }, 
        { 
            "$match" : { 
                "SUPPLIER_ID" : { 
                    "$ne" : null
                }, 
                "Books_issued.4" : { 
                    "$exists" : true
                }
            }
        }, 
        { 
            "$project" : { 
                "_id" : 0.0, 
                "book_code" : "$BOOK_CODE", 
                "BOOK_TITLE" : 1.0
            }
        }
    ]
);

                
/* name of the book which has been issued atleast twice 
and sort the result based on name of the book  ascending */ 
/*
select  det.book_code, det.BOOK_TITLE
from lms_book_details det  inner join lms_book_issue iss on ( det.book_code = iss.book_code)
group by det.book_code,det.BOOK_TITLE
having count(*) >=2
order by BOOK_TITLE asc;
*/

db.LMS_BOOK_DETAILS.aggregate([{
    "$lookup":{
            "from": "LMS_BOOK_ISSUE",
            "localField": "BOOK_CODE",
            "foreignField": "BOOK_CODE",
            "as": "book_issued"
    }
    }, 
    { 
        "$unwind" : { 
            "path" : "$book_issued"
        }
    }, 
    {
        "$group": {
                "_id": {"BOOK_CODE": "$BOOK_CODE",
                        "BOOK_TITLE":"$BOOK_TITLE"    
                       },
                "cnt": {
                        "$sum" : 1.0
                        }
                }
    },
    {
        "$match": {
                "book_issued": {$ne: []},
                "cnt": {$gte : 6}
                }
    },
    {
    "$sort":
        {
          "_id.BOOK_TITLE":1  
        }
    },
    {
    "$project":
    {
        "BOOK_CODE":"$_id.BOOK_CODE",
        "BOOK_TITLE":"$_id.BOOK_TITLE",
        "_id":0.0
    }
    }
])

/*
-- total number of books placed on given rack number 
-- such that edition of the book is atleast 3 
-- and it is supplied by a supplier who has a rediff / gmail account
-- and the book is issued to the students who are permanent in status
*/

// Side note : the count that we are doing should be that of book_code and not of number of issuances

/* sample O/P
RACK_NUM	Total
A1			2
A3			1
*/
db.LMS_BOOK_DETAILS.aggregate([])

db.LMS_SUPPLIERS_DETAILS.aggregate([])


/*
// Q- list the book_code and book_name of the book that has arrived later than they have been issued 
// [we are trying to see if we have some invalid date arrivals in our book_details]

select book_code , book_name 
from lms_book_details bd 
where exists 
(   select 1 from lms_book_issue bi 
    where bi.book_code = bd.book_code and  bd.date_arrival > bi.date_issue 
)

*/
db.LMS_BOOK_DETAILS.aggregate([{
    "$lookup":
    {
    "from": "LMS_BOOK_ISSUE",
    "let":
    {
     "dateArrival":"$DATE_ARRIVAL"
    },
    "pipeline":[{
        "$match": {
            "$expr": {
                "$eq":[
                     "$DATE_ISSUE","$$dateArrival"
                ]
         
            }
        }
    }],
    "as": "dates"
    }

}])

