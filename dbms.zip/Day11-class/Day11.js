// Working with ARRAYS 

// updating an array element using $ positional operator
db.students.insertMany( [
   { "_id" : 1, "grades" : [ 85, 85, 80 ] },
   { "_id" : 2, "grades" : [ 88, 90, 92 ] },
   { "_id" : 3, "grades" : [ 85, 100, 90 ] }
] )
db.students.find()
db.students.find({ _id: 1, grades: 80},{});
db.students.updateOne(
   { _id: 1, grades: 80 },
   { $set: { "grades.$" : 82 } }
)

db.students_deans_list.find()
db.students_deans_list.insertMany( [
   {
      _id: 8,
      activity_ids: [ 1, 2 ],
      grades: [ 90, 95 ],
      deans_list: [ 2021,2021, 2020 ],
      peans_list: [ 2021,2021, 2020 ]
   }
] )

// updating an array element using $ positional operator when there are multiple
// arrays in filter 
// doesnot works as expected since it does not know where to go in which array
// also it updates all the elements that match the filter for $ and not just
// one first element as with $ operator
db.students_deans_list.find()
db.students_deans_list.find({ activity_ids: 1, grades: 95, deans_list: 2021 })
db.students_deans_list.updateOne(
   { activity_ids: 1, grades: 95, deans_list: 2020 },
   { $set: { "deans_list.$": 2025 } }
)


// using array filter we can update as expected even 
// when we have multiple array elements that match the array filter 
db.students_deans_list.updateOne(
   {  deans_list: 2025 },
   { $set: { "deans_list.$[element]": 2020} },
    { arrayFilters: [ { "element": { $eq: 2025 } } ] }
)

// we can use the array filter across multiple arrays 
db.students_deans_list.updateOne(
   {  activity_ids: 1, grades: 95, deans_list: 2020 },
   { $set: { "deans_list.$[element]": 2022 ,"peans_list.$[element]": 2022 , "grades.$[element]": 2030} },
   { arrayFilters: [ { "element": { $eq: 2020 } } ] }
)
db.students_deans_list.find()
// update all elements of the array since we are using $[]
db.students_deans_list.updateOne(
   { activity_ids: 1, grades: 95, deans_list: 2022 },
   { $set: { "deans_list.$[]": 2027 } }
)

// pull few elements from deans_list
db.students_deans_list.updateOne(
   { activity_ids: 1, grades: 95, deans_list: 2027 },
   { $pull: { deans_list: 2027 } }
)

// pop last element from peans_list
db.students_deans_list.updateOne(
   { activity_ids: 1, grades: 95},
   { $pop: { peans_list: 1 } }
)

// pop first element from peans_list
db.students_deans_list.updateOne(
   { activity_ids: 1, grades: 95},
   { $pop: { peans_list: -1 } }
)

// push one array element to the grades
db.students_deans_list.updateOne(
   { activity_ids: 2, grades: 95 },
   { $push: { grades: 11 } }
)

//we can keep just {} brackets also instead of inserting values in {} brackets
db.students_deans_list.updateOne(
   { },
   { $push: { grades: 15 } }
)

db.students_deans_list.find()
// push multiple array element to the grades
db.students_deans_list.updateOne(
   { activity_ids: 1, grades: 95 },
   { $push: { grades: { $each: [ 1, 2, 3 ] } } }
)

// push multiple array element to the grades , sort(1 asc , -1 desc ) them in asc and slice top 3 
db.students_deans_list.updateOne(
   { activity_ids: 1 },
   { $push: { grades: { $each: [ 4, 1, 2 ], $sort: 1} } }
)

//, , $slice: 3 
db.students_deans_list.updateOne(
   { activity_ids: 1 },
   { $push: { grades: { $each: [ 10, 5, 15 ], $sort: -1,$slice: 5} } }
)


// pull all elements from deans_list
db.students_deans_list.updateOne(
   { activity_ids: 1 },
   { $pull: { grades: {$gt: - 500} } }
)

db.students_deans_list.find()
// push an element that already exists 
db.students_deans_list.updateOne(
   { activity_ids: 1},
   { $push: { grades: 11 } }
)

// add to set an element that already exists 
db.students_deans_list.updateOne(
   { activity_ids: 1},
   { $addToSet: { grades: 11 } }
)

// add to set an element that already exists 
db.students_deans_list.updateOne(
   { activity_ids: 1},
   { $addToSet: { grades: 12 } }
)

// add to set an element at a given position 
//To use the $position modifier, it must appear with the $each modifier.
// for now we could not find a way to add a single element without each operator 

db.students_deans_list.updateOne(
   { activity_ids: 1},
   { $push: { grades: {$each: [120]  ,  $position: 4 } }}
)

db.students_deans_list.find()




// difference between elemMatch and $all

db.trial.insertMany(
[
{
   "_id" : "abc",
    "city" : ["Pune","Mumbai","Nagpur"]
},
{
   "_id" : "pqr",
    "city" : ["Mumbai","Pune","Bangalore","Nagpur"]
},
{
   "_id" : "xyz",
    "city" : ["Chennai","Kolkatta","Delhi"]
},
{
   "_id" : "lmn",
    "city" : ["Chennai","Kolkatta","Pune"]
}
]
);

// $all is list of values (in and )
db.trial.find({"city" : {$all : ["Pune","Mumbai"]}},{});
// $elemMatch is list of Queries ( in and ) 
db.trial.find({"city" : {$elemMatch : {$eq: "Pune",$eq: "Mumbai"}}},{});

// $elemMatch is list of Queries (we used $in to make it work like or between queries) 
db.trial.find({"city" : {$elemMatch : {$in: [/Pune/,/Mumbai/]}}},{});

// $size will provide  size of tha array 
db.trial.find({"city" : { $size: 2 } },{});

-----
// using $inc operator in the array to increment by a given value 
db.students_deans_list.updateOne(
   { activity_ids: 1},
   { $inc: { "grades.$[]": 1 } }
)

// not working 
db.students_deans_list.updateOne(
   { activity_ids: 1},
   { $set: { "grades.$[]": {$add: [ "$grades.$[]", 1]}} }
)

// using $min value 

db.students_deans_list.updateOne(
   { activity_ids: 1},
   { $min: { "peans_list.$[]": 1 } }
)

db.students_deans_list.updateOne(
   { activity_ids: 1},
   { $min: { "peans_list.$[]": 10 } }
)

// using $max value 

db.students_deans_list.updateOne(
   { activity_ids: 1},
   { $max: { "peans_list.$[]": 0 } }
)

db.students_deans_list.updateOne(
   { activity_ids: 1},
   { $max: { "peans_list.$[]": 10 } }
)

// using $mul value 
db.students_deans_list.updateOne(
   { activity_ids: 1},
   { $mul: { "peans_list.$[]": 1.5 } }
)

// using $rename field 
db.students_deans_list.updateOne(
   { activity_ids: 1},
   { $rename: { "peans_list": "peas_list" } }
)
db.students_deans_list.find();
// update without $setOnInsert clause
db.students_deans_list.updateOne(
   {"_id" : 9.0},
   {$set : {"grades" : [1,2,3]}},
   {upsert  : true }
)

// update with $setOnInsert clause

db.students_deans_list.updateOne(
   {"_id" : 10.0},
   {
       $set : {"grades" : [1,2,3]},
       $setOnInsert: { "activity_ids" : [1.0,2.0] },
   },
   {upsert  : true }
)






















