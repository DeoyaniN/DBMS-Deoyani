//----------------------
//exercises on aggregate function with simple where and project clauses 
//----------------------

// select *  from customer 
db.customer.find({},{});
db.customer.aggregate([]);
// select *  from customer where address = 'Pune'
db.customer.find({"address": /pune/i},{})

db.customer.aggregate([
{
    $match:{"address": /pune/i}
}
]);
// select * from customer where street_no = 123
db.customer.find({},{"billing_address.street_no": 123});
db.customer.aggregate([
{$match:{"billing_address.street_no": 123}}]);

// select * from customer where total_cost > 350

db.customer.find({},{});
db.customer.aggregate([
{$match:{"Cart.total_cost":{$gt:350}}}
]);

// select * from customer where total_cost > 350 and address = 'Pune'

db.customer.find({},{});
db.customer.aggregate([
{$match : {$and :[{"Cart.total_cost": {$gt:350} , "address":/pune/i}]}}
]);


// select * from customer where address in ('Pune','Chennai')

db.customer.find({},{});
db.customer.aggregate([
{$match : {"address":{$in: ["Chennai","Pune"]}}}
]);

// select * from customer where lower(address) in ('pune','chennai')

db.customer.aggregate([
{$match : {"address": {$in: [/Chennai/i,/Pune/i]}}}
]);

// select * from customer where address != 'Chennai'

db.customer.aggregate([
{$match : {"address": {$nin: [/Chennai/i]}}}
]);
 
// select * from customer where address like '%pune%'


db.customer.aggregate([
{$match : {"address": {$in: [/pune/i]}}}
]);
// select * from customer where lower(address) like '%pune%'

// select * from  customer.Cart.added_products[] where [].product_id = 'X001' // invalid syntax just for reference
db.customer.find({ "Cart.added_products": {$elemMatch: { "product_id" : "X001"} }  },{});

// select * from  customer.Cart.added_products[] where [].product_id = 'X003' // invalid syntax just for reference
db.customer.find({ "Cart.added_products": {$elemMatch: { "product_id" : "X003"} }  },{});
