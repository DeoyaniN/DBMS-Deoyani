/*1) Create table named 
lms_members(MEMBER_ID	varchar2, MEMBER_NAME varchar2,	CITY varchar2,	DATE_REGISTER date, DATE_EXPIRE	date, MEMBERSHIP_STATUS varchar2) 
with constraints
  i) primary key constraint on MEMBER_ID
  ii) check constraint on DATE_REGISTER such that DATE_REGISTER > '01-01-2022'
  iii) not null constraint on DATE_EXPIRE
  iv) unique and not null constraint on MEMBER_NAME 

2) drop all constraints 
3) apply all constraints again using alter table command the one's defined in step1
*/
 Create table lms_members
 (MEMBER_ID	varchar2(100), 
 MEMBER_NAME varchar2(100) constraint notNullMemberName not null,	
 CITY varchar2(100),	
 DATE_REGISTER date constraint notNullDateRegister not null, 
 DATE_EXPIRE	date, 
 MEMBERSHIP_STATUS varchar2(100),
 constraint pk_lms_members primary key (MEMBER_ID),
 constraint ck_date_register check (DATE_REGISTER > to_date('01-01-2022','dd-mm-yyyy')),
 constraint uk_member_name unique (MEMBER_NAME)
 ); 
 
 alter table lms_members drop constraint notNullMemberName;
 alter table lms_members drop constraint ck_date_register;
 alter table lms_members drop constraint notNullDateRegister;
 alter table lms_members drop constraint pk_lms_members;
 alter table lms_members drop constraint uk_member_name;

alter table lms_members add constraint pk_lms_members primary key (MEMBER_ID);
alter table lms_members add constraint ck_date_register check (DATE_REGISTER > to_date('01-01-2022','dd-mm-yyyy'));
alter table lms_members add constraint uk_member_name unique (MEMBER_NAME);
alter table lms_members modify(MEMBER_NAME not null);
alter table lms_members modify(DATE_EXPIRE not null);


-- 4) Insert following data -- use to_date('12-12-2012','dd-mm-yyyy') to store the hardcoded date
--   and observe why the cosntraint failed/ passed
--   i) primary key constraint on MEMBER_ID
--   ii) check constraint on DATE_REGISTER such that DATE_REGISTER > '01-01-2022'
--   iii) not null constraint on DATE_EXPIRE
--   iv) unique and not null constraint on MEMBER_NAME 
-- LM009	Nikita	Delhi	12-12-2022	12-12-2023	Temporary	rajori road          PASSED
-- LM009	Niki	Pune	02-12-2022	02-12-2023	Temporary	bhutan               FAILED
-- null	Rohit	Mumbai	09-12-2022	09-12-2023	Temporary	bhutan                   FAILED
-- LM027	Priti	USA		01-06-2018	11-05-2023	Permanent	Texas                FAILED
-- LM020	Supriya	Delhi	12-12-2022	null     	Temporary	uttam nagar          FAILED
-- LM024	Gaurav	Delhi	12-06-2022	12-05-2023	Temporary	nawada               PASSED
-- LM025	Gaurav	pune	22-06-2022	22-05-2023	Permanent	pcmc                 FAILED
-- LM026	null	nepal	02-06-2022	29-05-2023	Permanent	nepal                FAILED
-- LM032	Sehwag	India	02-06-2022	29-05-2023	Permanent	Nawada               PASSED

insert INTO lms_members
(MEMBER_ID, MEMBER_NAME,	CITY,	DATE_REGISTER, DATE_EXPIRE, MEMBERSHIP_STATUS)
values   ('LM009','Nikita', 'Delhi',	to_date('12-12-2022','dd-mm-yyyy'),	to_date('12-12-2023','dd-mm-yyyy'),	'Temporary');
insert INTO lms_members
(MEMBER_ID, MEMBER_NAME,	CITY,	DATE_REGISTER, DATE_EXPIRE, MEMBERSHIP_STATUS)
values('LM009',	'Niki',	'Pune',	to_date('02-12-2022','dd-mm-yyyy'),	to_date('02-12-2023','dd-mm-yyyy'),	'Temporary');
insert INTO lms_members
(MEMBER_ID, MEMBER_NAME,	CITY,	DATE_REGISTER, DATE_EXPIRE, MEMBERSHIP_STATUS)
values(null,	'Rohit',	'Mumbai', to_date('09-12-2022','dd-mm-yyyy'), to_date('09-12-2023','dd-mm-yyyy'),'Temporary');
insert INTO lms_members
(MEMBER_ID, MEMBER_NAME,	CITY,	DATE_REGISTER, DATE_EXPIRE, MEMBERSHIP_STATUS)
values('LM027','Priti',	'USA',	to_date('01-06-2018','dd-mm-yyyy'),	to_date('11-05-2023','dd-mm-yyyy'),	'Permanent');
insert INTO lms_members
(MEMBER_ID, MEMBER_NAME,	CITY,	DATE_REGISTER, DATE_EXPIRE, MEMBERSHIP_STATUS)
values('LM020',	'Supriya',	'Delhi',	to_date('12-12-2022','dd-mm-yyyy'),	null, 'Temporary');
insert INTO lms_members
(MEMBER_ID, MEMBER_NAME,	CITY,	DATE_REGISTER, DATE_EXPIRE, MEMBERSHIP_STATUS)
values('LM024',	'Gaurav',	'Delhi',	to_date('12-06-2022','dd-mm-yyyy'),to_date('12-05-2023','dd-mm-yyyy'),	'Temporary');
insert INTO lms_members
(MEMBER_ID, MEMBER_NAME,	CITY,	DATE_REGISTER, DATE_EXPIRE, MEMBERSHIP_STATUS)
values('LM025',	'Gaurav',	'pune', to_date('22-06-2022','dd-mm-yyyy'),	to_date('22-05-2023','dd-mm-yyyy'),'Permanent');
insert INTO lms_members
(MEMBER_ID, MEMBER_NAME,	CITY,	DATE_REGISTER, DATE_EXPIRE, MEMBERSHIP_STATUS)
values('LM026',	null,	'nepal',	to_date('02-06-2022','dd-mm-yyyy'),	to_date('29-05-2023','dd-mm-yyyy'),'Permanent');
insert INTO  lms_members
(MEMBER_ID, MEMBER_NAME,	CITY,	DATE_REGISTER, DATE_EXPIRE, MEMBERSHIP_STATUS)
values('LM032',	'Sehwag',	'India',	to_date('02-06-2022','dd-mm-yyyy'), to_date('29-05-2023','dd-mm-yyyy'),	'Permanent');


