/*Exercise 02 -- Constraints [Assignment]
----------------------------------------
1) Create table named 
Create table named lms_suppliers_details(SUPPLIER_ID varchar2,SUPPLIER_NAME varchar2,ADDRESS	varchar2, CONTACT number,EMAIL varchar2)
with constraints
  i) primary key constraint on SUPPLIER_ID
  ii) not null constraint on CONTACT
  iii) unique and not null constraint on SUPPLIER_NAME 

2) drop all constraints 
3) apply all constraints again using alter table command the one's defined in step1*/

Create table lms_suppliers_details
(SUPPLIER_ID varchar2(100),
SUPPLIER_NAME varchar2(100) constraint notnull_SUPPLIER_NAME not null ,
ADDRESS	varchar2(100),
CONTACT number constraint notnull_CONTACT not null,
EMAIL varchar2(100),
constraint pk_SUPPLIER_ID primary key (SUPPLIER_ID ),
constraint uk_SUPPLIER_NAME unique (SUPPLIER_NAME)
);

alter table lms_suppliers_details drop constraint  pk_SUPPLIER_ID;
alter table lms_suppliers_details drop constraint uk_SUPPLIER_NAME;
alter table lms_suppliers_details modify (SUPPLIER_NAME null);
alter table lms_suppliers_details modify (CONTACT null);

alter table lms_suppliers_details modify (SUPPLIER_NAME not null);
alter table lms_suppliers_details modify (CONTACT not null);
alter table lms_suppliers_details 
add constraint pk_SUPPLIER_ID primary key (SUPPLIER_ID );
alter table lms_suppliers_details 
add constraint uk_SUPPLIER_NAME unique (SUPPLIER_NAME);

/*4) Insert following data -- use to_date('12-12-2012','dd-mm-yyyy') to store the hardcoded date
   and observe why the constraint failed/ passed
 
S01		SINGAPORE SHOPPEE	CHENNAI		9894123555	sing@gmail.com // pass   PASS
S01		Test	  			CHENNAI		9894123555	sing@gmail.com // fail   FAIL
NUll	Flat	  			CHENNAI		9894123555	sing@gmail.com // fail   FAIL
S02		JK Stores		    MUMBAI		null		jks@yahoo.com // fail    FAIL
S03		SINGAPORE SHOPPEE   TRIVANDRUM	9444411222	rose@gmail.com // fail   FAIL
S03		null			    TRIVANDRUM	9444411222	rose@gmail.com // fail   FAIL
*/

insert into lms_suppliers_details
(SUPPLIER_ID, SUPPLIER_NAME, ADDRESS, CONTACT, EMAIL)
values('S01', 'SINGAPORE SHOPPEE', 'CHENNAI', 9894123555,'sing@gmail.com');

insert into lms_suppliers_details
(SUPPLIER_ID, SUPPLIER_NAME, ADDRESS, CONTACT, EMAIL)
values('S01',	'Test',	'CHENNAI',9894123555,'sing@gmail.com');

insert into lms_suppliers_details
(SUPPLIER_ID, SUPPLIER_NAME, ADDRESS, CONTACT, EMAIL)
values(NUll,'Flat',	'CHENNAI',	9894123555,	'sing@gmail.com');

insert into lms_suppliers_details
(SUPPLIER_ID, SUPPLIER_NAME, ADDRESS, CONTACT, EMAIL)
values('S02', 'JK Stores', 'MUMBAI', null,'jks@yahoo.com');

insert into lms_suppliers_details
(SUPPLIER_ID, SUPPLIER_NAME, ADDRESS, CONTACT, EMAIL)
values('S03', 'SINGAPORE SHOPPEE', 'TRIVANDRUM', 9444411222, 'rose@gmail.com');

insert into lms_suppliers_details
(SUPPLIER_ID, SUPPLIER_NAME, ADDRESS, CONTACT, EMAIL)
values('S03',	null, 'TRIVANDRUM',	9444411222, 'rose@gmail.com');