/*Question : Supplier names of all suppliers whose address is 'MUMBAI'
1) identify the source of data : lms_suppliers_details
2) filter on column : address
3) project column : supplier_name

o/p:

SUPPLIER_NAME
-------------
JK Stores
AKBAR STORE
D MART
ZOMATO*/

select supplier_name
from lms_suppliers_details
where upper(address)='MUMBAI';

/*Question : Supplier names of all suppliers whose address is 'MUMBAI'
1) identify the source of data : lms_suppliers_details
2) filter on column : address
3) project column : supplier_name

o/p:

SUPPLIER_NAME
-------------
JK Stores
AKBAR STORE
D MART
ZOMATO*/

select supplier_name
from lms_suppliers_details
where upper(address)='MUMBAI';

/*Question : Names of the books who belong to category JAVA
1) identify the source of data : lms_book_details 
2) filter on column : CATEGORY
3) project column : BOOK_TITLE

BOOK_TITLE
-------------------------
Java How To Do Program
Java: The Complete Reference
Java How To Do Program
Java: The Complete Reference
Java How To Do Program
Java: The Complete Reference
Head First Design Patterns: A Brain-Friendly Guide
*/
select BOOK_TITLE 
from lms_book_details
where lower(category)='java';


-- Question : Names of the members who stay in city Pune
-- 1) identify the source of data : lms_members 
-- 2) filter on column : CITY
-- 3) project column : MEMBER_NAME

-- MEMBER_NAME
-- ------------
-- Amruta
-- Mayur
-- Renuka
-- Smita

select member_name
from lms_members
where lower(city) ='pune';

/*Question :Names of the members and date of registration who stay in city (Pune/Mumbai/Bangalore)
1) identify the source of data : lms_members 
2) filter on column : CITY [Pune or Mumbai or Bangalore]
3) project column : MEMBER_NAME,DATE_REGISTER

MEMBER_NAME			DATE_REGISTER               -- and/or operator
----------------------------------              true 	OR		true      = true
Amruta				02-03-2020                  false	OR		true      = true
Gautam				12-06-2018                  true	OR		false	  = true
Mayur				19-09-2019                  false	OR		false     = false
Nikhil				09-03-2020                  
Renuka				02-03-2020                  true 	AND		true      = true
Sayali				12-06-2018                  false	AND		true      = false
Smita				19-09-2019                  true	AND		false	  = false
Snehal				09-03-2020                  false	AND		false     = false
Ritesh				12-06-2018
*/

select MEMBER_NAME,DATE_REGISTER
from lms_members
where lower(city) in ('pune','mumbai','bangalore');

-- Question :Names of the books who belong to category JAVA and author is "Paul J. Deitel"
-- 1) identify the source of data : lms_book_details 
-- 2) filter on column : CATEGORY AND AUTHOR
-- 3) project column : BOOK_TITLE

-- BOOK_TITLE
-- --------------------------
-- Java How To Do Program
-- Java How To Do Program
-- Java How To Do Program

select book_title
from lms_book_details
where lower(CATEGORY) = 'java'
AND lower(AUTHOR)= lower('Paul J. Deitel');

-- Question : Member_id and book_code of all issuances that have not paid any fine 
-- 1) identify the source of data : lms_book_issue 
-- 2) filter on column : FINE_RANGE
-- 3) project column : MEMBER_ID	BOOK_CODE

-- MEMBER_ID	BOOK_CODE
-- ------------------------
-- LM001		BL000001
-- LM005		BL000005
-- LM001		BL000002
-- LM005		BL000002
-- LM001		BL000001
-- LM005		BL000005
-- LM001		BL000002
-- LM005		BL000002

select MEMBER_ID,BOOK_CODE
from lms_book_issue 
where FINE_RANGE is null;

-- Question : Member_id and book_code of all issuances where DATE_RETURN < DATE_RETURNED [Fine pay]

-- 1) identify the source of data : lms_book_issue 
-- 2) filter on column : FINE_RANGE  -- =IF(E3<F3,"OUT")
-- 3) project column : MEMBER_ID	BOOK_CODE
	
	
-- MEMBER_ID	BOOK_CODE
-- --------------------------
-- LM002		BL000002
-- LM003		BL000007
-- LM004		BL000005
-- LM003		BL000007
-- LM002		BL000001
-- LM003		BL000005
-- LM004		BL000007
-- LM003		BL000001
-- LM002		BL000002
-- LM003		BL000007
-- LM004		BL000005
-- LM003		BL000007
-- LM002		BL000001
-- LM003		BL000005
-- LM004		BL000007
-- LM003		BL000001

select MEMBER_ID, BOOK_CODE
from lms_book_issue
-- where fine_range is not null
where DATE_RETURN < DATE_RETURNED
;

/*Question : Name of the book and "It is placed on rack num <Racknum_value>" display where the category is python 
1) identify the source of data : lms_book_details 
2) filter on column : Category
3) project column : BOOK_TITLE, <Derived column named display >


BOOK_TITLE                                                   display
--------------------------------------------------------------------------------------------
Python Cookbook: Recipes for Mastering Python 3              It is placed on rack num -
Learn Python in 1 Day                                        It is placed on rack num A3
Python Programming:An Introduction to Computer Science       It is placed on rack num -
	
*/

select BOOK_TITLE,  concat('It is placed on rack num: ', rack_num) display
from lms_book_details
where lower(Category)='python';