/* category of book ,
    total number of books under that category 
    such that the category has more than 2 books 
*/
select category, count(*) count_cat
from lms_book_details
group by category
having count(*) >2;

/* book code and name of the book which has been issued atleast twice */ 

select  a.book_code, a.book_title, count(b.book_issue_no) count_cat
from lms_book_details a
inner join lms_book_issue b
on (a.book_code =b.book_code)
group by a.book_code, a.book_title
having count(b.book_issue_no) >=2;

/* book code and name of the book which has been issued atleast twice to a member*/

select  a.book_code, a.book_title, count(b.book_issue_no) count_
from lms_book_details a
inner join lms_book_issue b
on (a.book_code =b.book_code)
inner join lms_members c
on (b.member_id =c.member_id)
group by a.book_code, a.book_title, b.member_id
having count(b.book_issue_no) >=2;

/* book codes and their issued counts */
 select  a.book_code, count(b.book_issue_no) count_
from lms_book_details a
inner join lms_book_issue b
on (a.book_code =b.book_code)
group by  a.book_code;

/* book_code and name of the book which has been issued more than 4 times 
   and has more than 0 suppliers 
   (Note: Java how to program has 2 book codes because of different published date) 
*/
select a.book_title, decode(a.book_code, 'BL000005','BL000001',a.book_code) book_code,count(book_issue_no) count_ --, count(c.supplier_id)
from  lms_book_details a
inner join lms_book_issue b
on (a.book_code=b.book_code)
inner join lms_suppliers_details c
on (c.supplier_id=a.supplier_id)
group by a.book_title, decode(a.book_code, 'BL000005','BL000001', a.book_code) 
having count(book_issue_no)  >4 ;

select *
from  lms_book_details a
inner join lms_book_issue b
on (a.book_code=b.book_code);

select a.book_code ,a.book_title, count(b.book_issue) count_ --, count(c.supplier_id)
from  lms_book_details a
inner join lms_book_issue b
on (a.book_code=b.book_code)
inner join lms_suppliers_details c
on (c.supplier_id=a.supplier_id)
group by a.book_code ,a.book_title
having count(b.book_issue)  >4 ;
/* name of the book which has been issued more than 4 times and has more than 0 suppliers */
select lbd.book_title, count(lbd.book_code)
from lms_book_details lbd
inner join lms_book_issue lbi
on lbi.book_code=lbd.book_code
inner join lms_suppliers_details lsd
on lsd.supplier_ID=lbd.supplier_ID
where lsd.supplier_ID is not null
group by lbi.book_code,lbd.book_title
having count(lbi.book_code)  >4;


select lbd.book_title, count(lbi.book_issue_no)
from lms_book_details lbd
inner join lms_book_issue lbi
on lbi.book_code=lbd.book_code
inner join lms_suppliers_details lsd
on lsd.supplier_ID=lbd.supplier_ID
group by lbd.book_title
having count(lbi.book_issue_no)  >4;

select *from lms_book_issue
select *from 
lms_suppliers_details
/*
-- name of the supplier along with his contact number with an  flag 'Y' or 'N'
-- 'y' -> he had supplied a book which has been issued to two or more members 
-- 'n' --> he had supplied a book which has been issued to  less than two members 
-- 'NA' --> if he hasn't supplied any book 


supplier_name supplier_contact flag
xyz             9090           Y    -> he had supplied a book which has been issued to two or more members 
abc             9090           N    -> he had supplied a book which has been issued to  less than two members 
efg             9090           NA   -> if he hasn't supplied any book 

*/
/* category of book ,
    total number of books under that category 
    such that the category has more than 2 books 
*/
select category, count(*) count_cat
from lms_book_details
group by category
having count(*) >2;

/* book code and name of the book which has been issued atleast twice */ 

select  a.book_code, a.book_title, count(b.book_issue_no) count_cat
from lms_book_details a
inner join lms_book_issue b
on (a.book_code =b.book_code)
group by a.book_code, a.book_title
having count(b.book_issue_no) >=2;

/* book code and name of the book which has been issued atleast twice to a member*/

select  a.book_code, a.book_title, count(b.book_issue_no) count_
from lms_book_details a
inner join lms_book_issue b
on (a.book_code =b.book_code)
inner join lms_members c
on (b.member_id =c.member_id)
group by a.book_code, a.book_title, b.member_id
having count(b.book_issue_no) >=2;

/* book codes and their issued counts */
 select  a.book_code, count(b.book_issue_no) count_
from lms_book_details a
inner join lms_book_issue b
on (a.book_code =b.book_code)
group by  a.book_code;

/* book_code and name of the book which has been issued more than 4 times 
   and has more than 0 suppliers 
   (Note: Java how to program has 2 book codes because of different published date) 
*/
select a.book_title, decode(a.book_code, 'BL000005','BL000001',a.book_code) book_code,count(book_issue_no) count_ --, count(c.supplier_id)
from  lms_book_details a
inner join lms_book_issue b
on (a.book_code=b.book_code)
inner join lms_suppliers_details c
on (c.supplier_id=a.supplier_id)
group by a.book_title, decode(a.book_code, 'BL000005','BL000001', a.book_code) 
having count(book_issue_no)  >4 ;

select *
from  lms_book_details a
inner join lms_book_issue b
on (a.book_code=b.book_code);

select a.book_code ,a.book_title, count(b.book_issue) count_ --, count(c.supplier_id)
from  lms_book_details a
inner join lms_book_issue b
on (a.book_code=b.book_code)
inner join lms_suppliers_details c
on (c.supplier_id=a.supplier_id)
group by a.book_code ,a.book_title
having count(b.book_issue)  >4 ;
/* name of the book which has been issued more than 4 times and has more than 0 suppliers */
select lbd.book_title, count(lbd.book_code)
from lms_book_details lbd
inner join lms_book_issue lbi
on lbi.book_code=lbd.book_code
inner join lms_suppliers_details lsd
on lsd.supplier_ID=lbd.supplier_ID
where lsd.supplier_ID is not null
group by lbi.book_code,lbd.book_title
having count(lbi.book_code)  >4;


select lbd.book_title, count(lbi.book_issue_no)
from lms_book_details lbd
inner join lms_book_issue lbi
on lbi.book_code=lbd.book_code
inner join lms_suppliers_details lsd
on lsd.supplier_ID=lbd.supplier_ID
group by lbd.book_title
having count(lbi.book_issue_no)  >4;

select *from lms_book_issue
select *from 
lms_suppliers_details
/*
-- name of the supplier along with his contact number with an  flag 'Y' or 'N'
-- 'y' -> he had supplied a book which has been issued to two or more members 
-- 'n' --> he had supplied a book which has been issued to  less than two members 
-- 'NA' --> if he hasn't supplied any book 
supplier_name supplier_contact flag
xyz             9090           Y    -> he had supplied a book which has been issued to two or more members 
abc             9090           N    -> he had supplied a book which has been issued to  less than two members 
efg             9090           NA   -> if he hasn't supplied any book 
*/


select supplier_name,contact, 
case
    when sum(count_supp) =0  then 'NA'
else
    case when sum(count_mem) >=2 then 'Y'
        when sum(count_mem)  <2 then 'N'
    end 
end flag
from
(select lsd.supplier_name,lsd.contact, count(distinct  lbi.member_id) count_mem, count( lbd.supplier_ID) count_supp
from lms_suppliers_details lsd
left join lms_book_details lbd
 on lsd.supplier_ID=lbd.supplier_ID
left join lms_book_issue lbi
on lbd.book_code=lbi.book_code
group by lsd.supplier_name,lsd.contact)
group by supplier_name,contact
order by flag desc
 ;

select lsd.supplier_name,lsd.contact
from lms_supplier_details lsd
 inner join lms_book_details lbd
 on lsd.supplier_ID=lbd.supplier_ID
left join lms_book_issue lbi
on lsd.book_code=lbi.book_code


select *from lms_book_issue;
select *from lms_suppliers_details;
select *from lms_book_details;