--------------------------------
What Group by and Having is ? What is the need for it ?
--------------------------------

-- group by on no column
select count(*) cnt
from lms_members
having count(*) > 12;

-- group by on 1 column
select MEMBERSHIP_STATUS, count(*) cnt
from lms_members lm
group by MEMBERSHIP_STATUS
having count(*) > 12;

-- group by on more than 1 column 
select MEMBERSHIP_STATUS,city, count(*) cnt
from lms_members 
group by MEMBERSHIP_STATUS,city
having count(*) > 12;

select * --count(supplier_id)
from lms_book_details 
----------------------------
-- aggregate functions introduction
----------------------------
create table test_aggregate( col1 number);
insert into test_aggregate values(1);
insert into test_aggregate values(2);
insert into test_aggregate values(3);
insert into test_aggregate values(4);

select col1 from test_aggregate;
select sum(col1) from test_aggregate;
select count(col1) from test_aggregate;
select min(col1) from test_aggregate;
select max(col1) from test_aggregate;
select avg(col1) AVG_COL from test_aggregate;

select sum(col1) ,count(col1) ,min(col1),max(col1),avg(col1) from test_aggregate;

--------------------
--Group by , having basic demo
--------------------
drop table seta;
create table seta ( col1 varchar2(100), col2 varchar2(100));
insert into seta values ('PUNE','GAURAV');
insert into seta values ('PUNE','SAGAR');
insert into seta values ('DELHI','DEVANSHU');
insert into seta values ('DELHI','PRATIK');
insert into seta values ('DELHI','DEVANDER');
insert into seta values ('JAIPUR','SHRUTI');

SELECT * FROM  SETA;
SELECT * FROM  SETA GROUP BY COL1;
SELECT col1,col2 FROM  SETA GROUP BY COL1;
SELECT col2 FROM  SETA GROUP BY COL1;
SELECT col1 FROM  SETA GROUP BY COL1;
SELECT col1,count(*) FROM  SETA GROUP BY COL1;
--
SELECT col1,count(*) FROM  SETA GROUP BY COL1 where  COUNT(*) > = 2 ;
SELECT col1,count(*) FROM  SETA GROUP BY COL1 having COUNT(*) > = 2 ;

-------------------
Full Fledged DEMO
-------------------
/* count of no of members in each city */

select city , count(*)
from lms_members 
group by city;

/* count of members against their membership_status */
status     cnt
Temporary   12
Permanant   13

select membership_status status, count(*) cnt
from lms_members 
group by membership_status;

/* count of suppliers who stay in PUNE/MUMBAI/DELHI against their city  */
select address , count(*) cnt_of_suppliers
from lms_suppliers_details 
where address in ('PUNE','MUMBAI','DELHI')
group by address

/* number of books in each category that are placed in rack_num A1/A2/A3 */
select category , count(*) cnt_against_category
from lms_book_details
where rack_num in ('A1','A2','A3')
group by category

/* number of books issued in the month of APRIL/MAY  */

select count(*), to_char(date_issue, 'MONTH') months
from lms_book_issue
--where to_char(date_issue, 'MONTH') in ('APRIL' , 'MAY')
where to_char(date_issue, 'MM') in (4,5)
group by TO_CHAR(date_issue, 'MONTH');

select  to_char(date_issue, 'MONTH') months

select  dump(to_char(date_issue, 'MONTH')), dump(to_char('APRIL')),  dump(cast ('APRIL' as varchar(100)))

select TO_CHAR(date_issue, 'MONTH'), count(*) cnt
from lms_book_issue
--where trim(to_char(date_issue, 'MONTH')) in (cast ('APRIL' as varchar2(100)) ,cast ('MAY' as varchar2(100)))
where length(to_char(date_issue, 'MONTH')) in ('APRIL','MAY')
group by TO_CHAR(date_issue, 'MONTH');

/*select count(*), to_char(date_issue, 'MONTH') as months
from lms_book_issue
group by TO_CHAR(date_issue, 'MONTH')
HAVING to_char(date_issue, 'MONTH') in ('APRIL')
;*/


SELECT sysdate , length(triM(TO_CHAR(sysdate, 'MONTH'))),instr(TO_CHAR(sysdate, 'MONTH'), ' ', 1), extract(month from sysdate) , to_char(sysdate,'MONTH'),dump(to_char(sysdate,'MONTH')) , dump(to_char('test')) from dual:


select count(*), extract(MONTH from date_issue) months
from lms_book_issue
--where to_char(date_issue, 'MONTH') in ('APRIL' , 'MAY')
where UPPER(extract(MONTH from date_issue)) in (4,5)
group by extract(MONTH from date_issue)
decode(extract(MONTH from date_issue),5,'MAY')
;

SELECT --decode(extract(MONTH from date_issue),(extract(MONTH from date_issue)), TO_CHAR(extract(MONTH from date_issue))), 
--decode(extract(MONTH from date_issue),5, 'MAY',4 , 'APRIL'), 
REPLACE(DATE_ISSUE,DATE_ISSUE,TO_CHAR( date_issue,'MONTH') ),
date_issue, 
extract(MONTH from date_issue),
TO_CHAR( date_issue,'MONTH')
FROM  lms_book_issue;


* count of members against their status and city */

status city count
temp   Pune  90
perm   Pune  90

select membership_status ,city, count(*)
from lms_members 
group by membership_status , city ;
-----------------------------

----------------- String Functions in Oracle ---------------------
-- https://www.oracletutorial.com/oracle-string-functions/
------------------------------------------------------------------

-- INSTR(string , substring [, start_position [, occurrence]])

SELECT  INSTR( 'This is a playlist', 'is' ) substring_location FROM   dual;
SELECT  INSTR( 'This is a playlist', 'is',1,1 ) substring_location FROM   dual;
SELECT  INSTR( 'This is a playlist', 'is',1,2 ) substring_location FROM   dual;
SELECT  INSTR( 'This is a playlist', 'is',1,2 ) substring_location FROM   dual;

-- SUBSTR( str, start_position [, substring_length, [, occurrence ]] );
SELECT  SUBSTR( 'Oracle Substring', 1, 6 ) SUBSTRING FROM   dual;
SELECT  SUBSTR( 'Oracle Substring', 1, 3 ) SUBSTRING FROM   dual;
SELECT  SUBSTR( 'Oracle Substring', -3, 3 ) SUBSTRING FROM   dual;

-- TRANSLATE(string, from_string, to_string)

/* The from_string argument can has more characters than  to_string argument.
In this case, the extra characters at the end of  
from_string have no corresponding characters in to_string.
If these extra characters appear in the input string,
then the TRANSLATE() function removes them from the result string.*/

select  TRANSLATE('12345', '143', 'bx') from dual  -- b2x5

---------------------------------
/* count of suppliers against their respective category of email accounts who have gmail and yahoo accounts eg: gmail/yahoo
category cnt 
gmail     6
yahoo     2
*/

SELECT A.*, sUBSTR(EMAIL,-9,9 ), INSTR(EMAIL, 'gmail', 1) ,  sUBSTR(EMAIL,INSTR(EMAIL, 'gmail', 5) ,9 )  --COUNT(*) 
FROM LMS_SUPPLIERS_DETAILS A
--WHERE INSTR(EMAIL, 'gmail', 5)>0 

where email like '%gmail%'



-- earlier solution (hardcoded one)
select substr(email,-9) category, count(*) cnt_against_category
from lms_suppliers_details sd
where email like '%gmail.com' or email like '%yahoo.com'
group by substr(email,-9);

-- intermediate
select email, instr ( email ,'@' ) ,
 substr(email,instr ( email ,'@' )+1 ) 
from lms_suppliers_details sd;

-- new expression
select substr(email,instr ( email ,'@' ) ) category,
decode
( substr(email,instr ( email ,'@' ) ),
'@yahoo.com','yahoo',
'@gmail.com','gmail',
'others'
)
new_category,
count(*) cnt_against_category
from lms_suppliers_details sd
--where email like '%gmail.com' or email like '%yahoo.com'
group by substr(email,instr ( email ,'@' ) );

-- final solution
select 
decode( substr(email,instr ( email ,'@' )) ,'@yahoo.com','yahoo','@gmail.com','gmail','Others') category, 
count(*) cnt_against_category
from lms_suppliers_details sd
group by decode( substr(email,instr ( email ,'@' )) ,'@yahoo.com','yahoo','@gmail.com','gmail','Others');

SELECT COUNT(*) , 
case when  email  like  '%gmail%' then 'gmail'
when  email  like  '%yahoo%'
then 'yahoo'
else 'others' 
end mails
FROM LMS_SUPPLIERS_DETAILS A
--where lower(email) like '%gmail%' OR lower( email) like '%yahoo%'
group by case when  email  like  '%gmail%' then 'gmail'
when  email  like  '%yahoo%'
then 'yahoo'
else 'others' 
end ;
