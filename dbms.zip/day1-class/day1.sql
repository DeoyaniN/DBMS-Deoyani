create table my_first_table
(
my_first_column number,
my_second_column varchar2(100),
my_third_column date,
my_fourth_column timestAMP
);

SELECT *FROM USER_TABLES;


SELECT *FROM USER_TAB_columns;


describe my_first_table_New;
drop table my_first_table;
describe my_first_table;

alter table  my_first_table add(my_fifth_column timestamp);


rename my_first_table to my_first_table_New;

describe my_first_table_New;