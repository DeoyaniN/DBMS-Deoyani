--Exercises
---------------------
--/* name of the members ordered on their names ascending */
select  *from lms_members
order by member_name asc;

--/* list the book_name and issuance_date , date_of_expected_return 
--Such that the books that are to be returned at the earliest are seen at the top */
select a.book_title, b.date_issue, b.date_return
from lms_book_details a
inner join lms_book_issue b
on a.book_code = b.book_code
order by date_return asc;

--/*  list all the members such that the oldest member (the very first member to my LMS) 
--    of my LMS appears at the top
--*/ 
select *
from lms_members lm
order by date_register asc;


/*
book_code and name 
of the book that have been issued 
*/

select book_code,book_title
from lms_book_details
where book_code in (select book_code from lms_book_issue);

BL000001	Java How To Do Program
BL000002	Java: The Complete Reference 
BL000007	Let Us C
BL000005	Java How To Do Program

select book_code,book_title
from lms_book_details a
where book_code in (select book_code from lms_book_issue b where a.book_code= b.book_code);

select book_code,book_title
from lms_book_details a
where exists  (select * from lms_book_issue b where a.book_code= b.book_code);

select book_code,book_title
from lms_book_details a
where exists  (select 1 from lms_book_issue b where a.book_code= b.book_code);

/* book issue details  of the member who belongs to Pune/mumbai/chennai  */

select *
from lms_book_issue a
where member_id in (select member_id 
                                        from lms_members b 
                                        where a.member_id = b.member_id 
                                        and lower(city) in ('pune','mumbai','chennai'))



select a.*, 
 (select b.city 
    from lms_members b 
    where a.member_id = b.member_id 
    and lower(city) in ('pune','mumbai','chennai')
    ) as city_members
from lms_book_issue a
where exists (select b.city 
                            from lms_members b 
                            where a.member_id = b.member_id 
                            and lower(city) in ('pune','mumbai','chennai')
                            ) 
--where member_id in

/* members who have never issued a book */

select member_name,member_id
from lms_members
where member_id not in
(select member_id from lms_book_issue );

select member_name, member_id
from lms_members a
where not exists (select * 
                            from lms_book_issue b 
                            where a.member_id = b.member_id);


/*
 name of the member whose  has issued a book ,
 that same book supplier belong to the same city as that of the member
*/

select * 
from lms_members lm
where exists (select member_id 
                        from lms_book_issue lbi
                        where lm.member_id =lbi.member_id
                        and exists (select *
                                            from lms_book_details lbd
                                            where lbi.book_code = lbd.book_code
                                            and exists (select *
                                                                from lms_suppliers_details lsd
                                                                where lsd.supplier_id =lbd.supplier_id
                                                                and lm.city =lsd.address)))
                                                                
/*
book_code and name of the book that have been issued 
*/

select book_code, book_title
from lms_book_details
where book_code in (select book_code from lms_book_issue);




