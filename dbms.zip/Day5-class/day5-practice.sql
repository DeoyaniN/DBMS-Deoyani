select MEMBER_NAME from lms_members where upper(member_name) like '%A%';
------------
SELECT *frOM LMS_SUPPLIERS_DETAILS ;
SELECT * FROM LMS_MEMBERS;
/* Name of the supplier that reside in chennai/delhi/ahmedabad */
SELECT SUPPLIER_NAME,ADDRESS FROM LMS_SUPPLIERS_DETAILS WHERE ADDRESS= 'CHENNAI' OR  ADDRESS='DELHI' OR ADDRESS='AHMEDABAD';
SELECT SUPPLIER_NAME,ADDRESS FROM LMS_SUPPLIERS_DETAILS WHERE ADDRESS IN ('CHENNAI','DELHI','AHMEDABAD');
/* Display Name of the member , City in which he resides , date of membership expiry,
    duration in days in which he is a member as of today
*/
SELECT MEMBER_NAME, CITY, DATE_REGISTER, DATE_EXPIRE, ROUND(SYSDATE- DATE_REGISTER) DURATIONDAYS
FROM LMS_MEMBERS;
/*  Name of the supplier , contact , email , Address who resides in either Mumbai Or Delhi 
    and email does not belong to gmail account*/
SELECT SUPPLIER_NAME,CONTACT,EMAIL,ADDRESS FROM LMS_SUPPLIERS_DETAILS
WHERE LOWER(ADDRESS) IN (LOWER('MUMBAI'),LOWER('DELHI'))
AND EMAIL not LIKE '%gmail.com'
/* name of the member who has an a/A in it and status is temporary */
select MEMBER_NAME from lms_members 
where MEMBERSHIP_STATUS='Temporary'
and (lower(MEMBER_NAME) like '%a%')
and (MEMBER_NAME like '%a%' or MEMBER_NAME like '%A%');
/* name of the member who resides in Pune and his membership_status is Permanent*/
select MEMBER_NAME from lms_members 
where lower(address) ='pune' 
and membership_status='Permanent';
/* name of the suppliers who has a gmail account*/
/* name of the books who were published by Tata Mcgraw Hill */
/*
Name of the book , 
Year in which it was published ,
publication name , 
Category ,
Type of Language (Java -> Object Oriented Language , C-> Procedural language )
for book that were published on or after Year 2005 or not published by Tata Mcgraw Hill
*/	