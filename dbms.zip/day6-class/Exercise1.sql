/* name of the book , publication , date of publication along with supplier name and his contact number 
Note : books that have no suppliers should not be displayed*/

select lbd.Book_title, lbd.publication , lbd.publish_date,lsd.supplier_name,lsd.contact
from LMS_SUPPLIERS_DETAILS lsd
inner join lms_book_details lbd
on lsd.supplier_ID=lbd.supplier_id;
/*name of the book , publication , date of publication along with supplier name and his contact number which may or may not have a supplier*/

select lbd.Book_title, lbd.publication , lbd.publish_date,lsd.supplier_name,lsd.contact
from LMS_book_DETAILS lbd
left join lms_suppliers_details lsd
on lsd.supplier_ID=lbd.supplier_id;

/* name of the member , status of his membership who have issued a book and never paid a fine  */
select lm.MEMBER_NAME, lm.MEMBERSHIP_STATUS,lbi.fine_range
from lms_members lm
inner join lms_book_issue lbi
on lm.member_ID=lbi.member_ID
where lbi.fine_range is null;
/* name of the member , status of his membership who have issued a book and paid atleast fine more than 74 rs*/
select lm.MEMBER_NAME, lm.MEMBERSHIP_STATUS,lbi.fine_range
from lms_members lm
inner join lms_book_issue lbi
on lm.member_ID=lbi.member_ID
where lbi.fine_range in ('R4','R5','R6');


select *from lms_book_issue;
select *from lms_members;
select *from LMS_SUPPLIERS_DETAILS;
select *from lms_book_details;