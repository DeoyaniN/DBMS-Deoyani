/* name of the member , status of his membership who have issued a book 
and paid atleast fine more than 74 rs 
and the supplier has a gmail account */

select distinct lm.member_name, lm.membership_status
from lms_members lm
inner join lms_book_issue lbi
on lm.member_id =lbi.member_id
inner join lms_book_details lbd
on lbi.book_code = lbd.book_code
inner join LMS_SUPPLIERS_DETAILS lsd
on lsd.supplier_id = lbd.supplier_id
inner join LMS_FINE_DETAILS lfd
on lfd.fine_range = lbi.fine_range
where lfd.fine_amount>74
and lower(lsd.email) like '%@gmail%';

/* name of the member who has issued a book which is not placed on any rack*/
select lm.member_name
from lms_members lm
inner join lms_book_issue lbi
on lm.member_id =lbi.member_id
inner join lms_book_details lbd
on lbd.book_code=lbi.book_code
where rack_num is null;

/* name of the supplier who has not supplied any book 
and that supplier lives in PUNE/MUMBAI/DELHI*/

select lsd.supplier_name
from LMS_SUPPLIERS_DETAILS lsd
left join lms_book_details lbd
on lsd.supplier_id = lbd.supplier_id
where lbd.supplier_id is null
and upper(lsd.address) in ('PUNE', 'MUMBAI', 'DELHI')
;
/* Name of the book , edition , publication that have never been issued  */

select lbd.book_title, lbd.book_edition, lbd.publication 
from lms_book_details lbd
left join lms_book_issue lbi
on lbd.book_code=lbi.book_code
where lbi.book_code is null;

/* Name of the book , edition , publication that have been issued to members
who have enrolled after 01-01-1999*/
select lbd.book_title, lbd.book_edition, lbd.publication,lbi.Date_issue
from lms_book_details lbd
inner join lms_book_issue lbi
on lbd.book_code=lbi.book_code
inner join lms_members lm
on lm.member_id=lbi.member_id
where lm.Date_register>to_date('01-01-1999', 'dd-mm-yyyy');

/* Name of the members who have issued a book later than 01-01-2000*/
select distinct  lm.member_name
from lms_members lm
inner join lms_book_issue lbi
on lm.member_id = lbi.member_id
where lbi.date_issue > to_date('01-01-2000','dd-mm-yyyy')
;

/* Name of the members who have issued a book and such that book supplier belongs to PUNE/MUMBAI/DELHI*/
select distinct lm.member_name
from lms_members lm
inner join lms_book_issue lbi
on lm.member_id=lbi.member_id
inner join lms_book_details lbd
on lbi.book_code= lbd.book_code
inner join LMS_SUPPLIERS_DETAILS lsd
on lsd.supplier_id=lbd.supplier_id
where upper(lsd.address) in ('PUNE','MUMBAI','DELHI');

/* Name of the members who have issued a book from the publication "The MIT Press" */

select * --lm.member_name 
from lms_members lm
inner join lms_book_issue lbi
on lm.member_id = lbi.member_id
inner join lms_book_details lbd
on lbi.book_code = lbd.book_code
where lower(lbd.publication) = 'the mit press';

select *from lms_book_issue;
select *from lms_members;
select *from LMS_SUPPLIERS_DETAILS;
select *from lms_book_details;


