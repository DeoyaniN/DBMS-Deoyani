Create table lms_book_details(BOOK_CODE varchar2(20),BOOK_TITLE varchar2(20),CATEGORY varchar2(20),AUTHOR varchar2(20),PUBLICATION varchar2(20),	PUBLISH_DATE date, BOOK_EDITION	number, PRICE number,RACK_NUM varchar2(20),	DATE_ARRIVAL date,	SUPPLIER_ID varchar2(10));
Drop table lms_book_details;
Create table lms_book_details(BOOK_CODE varchar2(20),BOOK_TITLE varchar2(20),CATEGORY varchar2(20),AUTHOR varchar2(20),PUBLICATION varchar2(20),	PUBLISH_DATE date, BOOK_EDITION	number, PRICE number,RACK_NUM varchar2(20),	DATE_ARRIVAL date,	SUPPLIER_ID varchar2(10));

Alter table lms_book_details add(ISBN VARCHAR2(20),CURRENCY VARCHAR2(20));
Alter table lms_book_details rename column CURRENCY to BOOK_CURRENCY;
Alter table lms_book_details drop column ISBN;
rename lms_book_details to lms_book_details_p;
alter table lms_book_details_p modify(BOOK_TITLE varchar2(40));
alter table lms_book_details_p modify(AUTHOR varchar2(100));
--e) Insert following data 
--BL000001	Java How To Do Program			JAVA	Paul J. Deitel	Prentice Hall		10-12-1999	6	600	A1	10-05-2011	S01
--BL000002	Java: The Complete Reference	JAVA	Herbert Schildt	Tata Mcgraw Hill	10-10-2011	5	750	A1	10-05-2011	S03
insert into lms_book_details_p values('BL000001',	'Java How To Do Program','JAVA','Paul J. Deitel','Prentice Hall',to_date('10-12-1999', 'dd-mm-yyyy'),6,	600,'A1',to_date('10-05-2011', 'dd-mm-yyyy'),'S01', null);
insert into lms_book_details_p values('BL000002',	'Java The complete reference','JAVA','Herbert Schildt	Tata Mcgraw Hill','Prentice Hall',to_date('10-10-2011', 'dd-mm-yyyy'),5,750	,'A1',to_date('10-05-2011', 'dd-mm-yyyy'),'S03', null);
--f) delete all the rows
--g) insert the data back again in point (e) 
--h) update for all rows CATEGORY column to 'JUNK'
delete lms_book_details_p;
insert into lms_book_details_p values('BL000001',	'Java How To Do Program','JAVA','Paul J. Deitel','Prentice Hall',to_date('10-12-1999', 'dd-mm-yyyy'),6,	600,'A1',to_date('10-05-2011', 'dd-mm-yyyy'),'S01', null);
insert into lms_book_details_p values('BL000002',	'Java The complete reference','JAVA','Herbert Schildt	Tata Mcgraw Hill','Prentice Hall',to_date('10-10-2011', 'dd-mm-yyyy'),5,750	,'A1',to_date('10-05-2011', 'dd-mm-yyyy'),'S03', null);
update lms_book_details_p set CATEGORY ='JUNK';
select *from lms_book_details_p;


--f)  TCL  -- please set your expectations by filling in ? in [? rows] before executing your code 
  -- <case 1>  -- rollback
	select * from lms_book_details_p;
	--[2 rows]
	--insert : BL000003	Java How To Do Program	JAVA	Paul J. Deitel	Prentice Hall	10-05-1999	6	600	A1	10-05-2012	S01
	insert into lms_book_details_p values('BL000003',	'Java How To Do Program',
	'JAVA','Paul J. Deitel','Prentice Hall',
	to_date('10-05-1999', 'dd-mm-yyyy'),6,600	,'A1',
	to_date('10-05-2012', 'dd-mm-yyyy'),'S01', null);
	
	select * from lms_book_details_p;
	--[3 rows]
	rollback;
	select * from lms_book_details_p;
	--[2 rows]

  -- <case 2> -- commit
	select * from lms_book_details_p;
	--[2 rows]
--	insert : BL000003	Java How To Do Program	JAVA	Paul J. Deitel	Prentice Hall	10-05-1999	6	600	A1	10-05-2012	S01
	insert into lms_book_details_p values('BL000003',	'Java How To Do Program',
	'JAVA','Paul J. Deitel','Prentice Hall',
	to_date('10-05-1999', 'dd-mm-yyyy'),6, 600	,'A1',
	to_date('10-05-2012', 'dd-mm-yyyy'),'S01', null);
	select * from lms_book_details_p;
	--[3 rows]
	commit;
	select * from lms_book_details_p;
	--[3 rows]

 /*<case 3> -- rollback to savepoint */
select * from lms_book_details_p;
exec savepoint s1;
/*insert : BL000004	Java: The Complete Reference	JAVA	Herbert Schildt	Tata Mcgraw Hill	10-10-2011	5	750	A1	11-05-2012	S01*/
insert into lms_book_details_p values('BL000004',	'Java: The Complete Reference',
'JAVA','Herbert Schildt	Tata','Mcgraw Hill',
to_date('10-10-2011', 'dd-mm-yyyy'),5, 750	,'A1',
to_date('10-05-2012', 'dd-mm-yyyy'),'S01', null);
select * from lms_book_details_p;
exec savepoint s2;
/*insert : BL000005	Java How To Do Program	JAVA	Paul J. Deitel	Prentice Hall	10-12-1999	6	600	A1	11-05-2012	S01*/
insert into lms_book_details_p values('BL000005',	'Java How To Do Program',
'JAVA','Paul J. Deitel','Prentice Hall',
to_date('10-12-1999', 'dd-mm-yyyy'),6, 600	,'A1',
to_date('11-05-2012', 'dd-mm-yyyy'),'S01', null);
select * from lms_book_details_p;
/*[5 rows]*/
rollback to savepoint s2;
select * from lms_book_details_p;
/*[4 rows]*/
 
 