 -------------------------------------------------------
/*Exercise Question 4 :*/
--------------------------------------------------------
Create table lms_book_issue
(BOOK_ISSUE_NO number(9),
MEMBER_ID varchar2(100),
BOOK_CODE varchar2(100),	
DATE_ISSUE date,
DATE_RETURN date,
DATE_RETURNED date,
FINE_RANGE varchar2(100)
);

Drop table lms_book_issue;

Create table lms_book_issue
(BOOK_ISSUE_NO number(9),
MEMBER_ID varchar2(100),
BOOK_CODE varchar2(100),	
DATE_ISSUE date,
DATE_RETURN date,
DATE_RETURNED date,
FINE_RANGE varchar2(100)
);

Alter table lms_book_issue add (Vendor_code VARCHAR2(100), place VARCHAR2(100));
Alter table lms_book_issue rename column place to vendor_place;
Alter table lms_book_issue drop column Vendor_code;
rename lms_book_issue to lms_suppliers_details_p;

insert into lms_suppliers_details_p
values(6,	'LM003',	'BL000007',	to_date('22-04-2012','dd-mm-yyyy'),	to_date('07-05-2012','dd-mm-yyyy'),	to_date('25-05-2012','dd-mm-yyyy'),'R4', null);

insert into lms_suppliers_details_p
(BOOK_ISSUE_NO, MEMBER_ID, BOOK_CODE,DATE_ISSUE,DATE_RETURN,DATE_RETURNED,FINE_RANGE)
values(12,	'LM003',	'BL000001',	to_date('22-04-2013','dd-mm-yyyy'),	to_date('07-05-2013','dd-mm-yyyy'),	to_date('25-05-2013','dd-mm-yyyy'),'R4');

delete lms_suppliers_details_p;

insert into lms_suppliers_details_p
values(6,	'LM003',	'BL000007',	to_date('22-04-2012','dd-mm-yyyy'),	to_date('07-05-2012','dd-mm-yyyy'),	to_date('25-05-2012','dd-mm-yyyy'),'R4', null);

insert into lms_suppliers_details_p
(BOOK_ISSUE_NO, MEMBER_ID, BOOK_CODE,DATE_ISSUE,DATE_RETURN,DATE_RETURNED,FINE_RANGE)
values(12,	'LM003',	'BL000001',	to_date('22-04-2013','dd-mm-yyyy'),	to_date('07-05-2013','dd-mm-yyyy'),	to_date('25-05-2013','dd-mm-yyyy'),'R4');

update lms_suppliers_details_p
set book_code = 'B0000001111';

select * from lms_suppliers_details_p;



--f)  TCL  -- please set your expectations by filling in ? in [? rows] before executing your code 
--<case 1>  -- rollback
select *from  lms_suppliers_details_p;
--[2 rows]
insert into lms_suppliers_details_p
values(18,	'LM003',	'BL000007',	to_date('07-05-2012','dd-mm-yyyy'),	to_date('22-05-2012','dd-mm-yyyy'),	to_date('11-06-2012','dd-mm-yyyy'),'R4', null);
select *from  lms_suppliers_details_p;
--[3 rows]
rollback;
select *from  lms_suppliers_details_p;
--[2 rows]
	
	
select *from  lms_suppliers_details_p;
--[2 rows]
insert into lms_suppliers_details_p
values(18,	'LM003',	'BL000007',	to_date('07-05-2012','dd-mm-yyyy'),	to_date('22-05-2012','dd-mm-yyyy'),	to_date('11-06-2012','dd-mm-yyyy'),'R4', null);
select *from  lms_suppliers_details_p;
--[3 rows]
commit;
select *from  lms_suppliers_details_p;
--[3 rows]
 
 select *from  lms_suppliers_details_p;
--[3 rows]
exec savepoint s1;
insert into lms_suppliers_details_p
values(18,	'LM003',	'BL000007',	to_date('07-05-2012','dd-mm-yyyy'),	to_date('22-05-2012','dd-mm-yyyy'),	to_date('11-06-2012','dd-mm-yyyy'),'R4', null);
select *from  lms_suppliers_details_p;
exec savepoint s2;
insert into lms_suppliers_details_p
values(24,	'LM003',	'BL000007',	to_date('07-05-2012','dd-mm-yyyy'),	to_date('22-05-2012','dd-mm-yyyy'),	to_date('11-06-2012','dd-mm-yyyy'),'R4', null);
--[5 rows]
rollback to savepoint s2;
select *from  lms_suppliers_details_p;
--[4 rows]