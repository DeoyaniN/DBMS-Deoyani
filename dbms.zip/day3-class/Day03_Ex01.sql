create table lms_members(Member_ID varchar2(20), Member_name varchar2(30), City varchar2(15), Date_Register Date, Date_Expire Date, Membership_status varchar2(20));
describe lms_members;
drop table lms_members;
create table lms_members(Member_ID varchar2(20), Member_name varchar2(30), City varchar2(15), Date_Register Date, Date_Expire Date, Membership_status varchar2(20));
alter table lms_members add (Address varchar2(40), Contact varchar2(10));
alter table lms_members rename column Address to member_Address; 
alter table lms_members modify (Contact Number) ;
alter table lms_members drop column Contact;
rename lms_members to lms_members_practice;
alter table lms_members_practice modify ( member_Address varchar2(3999));
describe  lms_members_practice;
insert into lms_members_practice (Member_ID, Member_name, City, Date_Register, Date_Expire, Membership_status, member_address)
values ('LM009', 'Nikita','Delhi', to_date('12-12-2012','dd-mm-yyyy'),to_date('12-12-2021','dd-mm-yyyy'),'Temporary','Rajori Road');
insert into lms_members_practice 
values ('LM020', 'Supriya','Delhi', to_date('12-12-2012','dd-mm-yyyy'),to_date('12-12-2021','dd-mm-yyyy'),'Temporary','Uttam Nagar');
insert into lms_members_practice (Member_ID, Member_name, City, Date_Register, Date_Expire, Membership_status, member_address)
values ('LM024', 'Gaurav','Delhi', to_date('12-06-2018','dd-mm-yyyy'),to_date('12-05-2020','dd-mm-yyyy'),'Temporary','Nawada');
commit;
delete lms_members_practice;
rollback;
insert into lms_members_practice (Member_ID, Member_name, City, Date_Register, Date_Expire, Membership_status, member_address)
values ('LM009', 'Nikita','Delhi', to_date('12-12-2012','dd-mm-yyyy'),to_date('12-12-2021','dd-mm-yyyy'),'Temporary','Rajori Road');
insert into lms_members_practice 
values ('LM020', 'Supriya','Delhi', to_date('12-12-2012','dd-mm-yyyy'),to_date('12-12-2021','dd-mm-yyyy'),'Temporary','Uttam Nagar');
insert into lms_members_practice (Member_ID, Member_name, City, Date_Register, Date_Expire, Membership_status, member_address)
values ('LM024', 'Gaurav','Delhi', to_date('12-06-2018','dd-mm-yyyy'),to_date('12-05-2020','dd-mm-yyyy'),'Temporary','Nawada');
update lms_members_practice set member_address='Karnataka';
select *from lms_members_practice;
