create table lms_suppliers_details(Supplier_id varchar2(10),Supplier_name varchar2(25),Address varchar2(25),Contact number,Email varchar2(20));
drop table lms_suppliers_details;
create table lms_suppliers_details(Supplier_id varchar2(10),Supplier_name varchar2(25),Address varchar2(25),Contact number,Email varchar2(20));
Alter table lms_suppliers_details add (Blood_Group varchar2(10), Country varchar2(10));
alter table lms_suppliers_details rename column country to Member_country;
alter table lms_suppliers_details modify Blood_Group varchar2(3008);
alter table lms_suppliers_details drop column Blood_Group ;
describe lms_suppliers_details;
rename lms_suppliers_details to lms_suppliers_details_P;


insert into lms_suppliers_details_P values('S01', 'Singapore Shopee', 'Chennai',9894123555, 'singh@gmail.com','India');
insert into lms_suppliers_details_P values('S02', 'JK Stores', 'Mumbai',98940123450, 'jks@yahoo.com','India');
insert into lms_suppliers_details_P values('S03', 'Rose Book Store', 'Trivendrum',9444411222, 'rose@gmail.com','India');
insert into lms_suppliers_details_P values('S04', 'Kavari Store', 'Delhi',8630001452, 'kavi@predif.com','India');
delete lms_suppliers_details_P;
insert into lms_suppliers_details_P values('S01', 'Singapore Shopee', 'Chennai',9894123555, 'singh@gmail.com','India');
insert into lms_suppliers_details_P values('S02', 'JK Stores', 'Mumbai',98940123450, 'jks@yahoo.com','India');
insert into lms_suppliers_details_P values('S03', 'Rose Book Store', 'Trivendrum',9444411222, 'rose@gmail.com','India');
insert into lms_suppliers_details_P values('S04', 'Kavari Store', 'Delhi',8630001452, 'kavi@predif.com','India');
update lms_suppliers_details_P set Member_country='USA';
select *from lms_suppliers_details_P;

--Case1 Rollback
select *from lms_suppliers_details_P;
--4 rows
insert into lms_suppliers_details_P values ('S12','Zomato','Mumbai',7855623440, 'money@gmail.com','India');
select *from lms_suppliers_details_P;
--5 rows
rollback;
select *from lms_suppliers_details_P;
-- 4rows

--Case2 Commit
select *from lms_suppliers_details_P;
--4 rows
insert into lms_suppliers_details_P values ('S10','Jio Mart','Delhi',8644001452, 'freerediff.com','India');
select *from lms_suppliers_details_P;
--5 rows
commit;
select *from lms_suppliers_details_P;
--5 rows

--Case3 rollback to savepoint
select *from lms_suppliers_details_P;
exec savepoint s1;
--5 rows
insert into lms_suppliers_details_P values ('S08','D-Mart','Mumbai',9904123450, 'dance@gmail.com','India');
exec savepoint s2;
insert into lms_suppliers_details_P values ('S06','Akbar Store','Mumbai',7855623100, 'akbarst@gaol.com','India');
exec savepoint s3;
select *from lms_suppliers_details_P;
--7 rows
rollback to savepoint s2;
select *from lms_suppliers_details_P;
--6 rows