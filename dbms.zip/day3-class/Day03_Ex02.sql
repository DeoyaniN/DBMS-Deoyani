--Case1 Rollback
select * from lms_members_practice; 
--[3 rows]
insert into lms_members_practice 
(Member_ID, Member_name, City, Date_Register, Date_Expire, Membership_status, member_address)
values ('LM011', 'Gaurav','Delhi', to_date('12-12-2012','dd-mm-yyyy'),to_date('12-12-2021','dd-mm-yyyy'),'Temporary','Rajori Road');
select * from lms_members_practice; 
--[4 rows]
rollback;
select * from lms_members_practice; 
--[3 rows]

--Case2 Commit
select * from lms_members_practice; 
--[3 rows]
insert into lms_members_practice 
(Member_ID, Member_name, City, Date_Register, Date_Expire, Membership_status, member_address)
values ('LM012', 'Gauri','Delhi', to_date('12-12-2012','dd-mm-yyyy'),to_date('12-12-2021','dd-mm-yyyy'),'Temporary','Uttam Nagar');
select * from lms_members_practice; 
--[4 rows]
commit;
select * from lms_members_practice; 
--[4 rows]
--Case3 Rollback to savepoint
select * from lms_members_practice; 
--[4 rows]
exec savepoint s1;
insert into lms_members_practice 
(Member_ID, Member_name, City, Date_Register, Date_Expire, Membership_status, member_address)
values ('LM013', 'Pratik','Delhi', to_date('12-12-2012','dd-mm-yyyy'),to_date('12-12-2021','dd-mm-yyyy'),'Temporary','Uttam Nagar');
exec savepoint s2;
insert into lms_members_practice 
(Member_ID, Member_name, City, Date_Register, Date_Expire, Membership_status, member_address)
values ('LM014', 'Deepak','Delhi', to_date('12-12-2012','dd-mm-yyyy'),to_date('12-12-2021','dd-mm-yyyy'),'Temporary','Uttam Nagar');
select * from lms_members_practice; 
--[6 rows]
rollback to savepoint s2;
select * from lms_members_practice; 
--[5 rows]
